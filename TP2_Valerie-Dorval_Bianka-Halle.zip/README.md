full-archetype
