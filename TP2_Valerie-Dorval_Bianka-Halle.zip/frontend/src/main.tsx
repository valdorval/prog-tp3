import { Router } from 'component/router';
import React from 'react';
import ReactDOM from 'react-dom';

ReactDOM.render(<Router />, document.getElementById('coreContainer'));
